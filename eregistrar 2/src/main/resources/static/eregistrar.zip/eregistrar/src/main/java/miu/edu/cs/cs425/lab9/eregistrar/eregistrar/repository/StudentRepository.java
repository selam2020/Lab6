package miu.edu.cs.cs425.lab9.eregistrar.eregistrar.repository;

import miu.edu.cs.cs425.lab9.eregistrar.eregistrar.model.Student;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository extends CrudRepository<Student,Long> {
}
