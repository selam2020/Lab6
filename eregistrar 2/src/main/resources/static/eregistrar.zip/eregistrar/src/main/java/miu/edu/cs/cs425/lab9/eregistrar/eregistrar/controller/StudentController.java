package miu.edu.cs.cs425.lab9.eregistrar.eregistrar.controller;

import miu.edu.cs.cs425.lab9.eregistrar.eregistrar.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StudentController {

StudentService studentService;
    @Autowired
   public StudentController(StudentService studentService){
        this.studentService=studentService;

   }

    @GetMapping(value={"/eregistrar/home/list"})
    public ModelAndView showStudetList(){
        ModelAndView modelAndView=  new ModelAndView();
        modelAndView.addObject("students",studentService.getListOfStudent());
         modelAndView.setViewName("student/list");
        return  modelAndView;

    }

}
