package miu.edu.cs.cs425.lab9.eregistrar.eregistrar.service;

import miu.edu.cs.cs425.lab9.eregistrar.eregistrar.model.Student;
import org.springframework.stereotype.Service;


public interface StudentService {

    public  Iterable<Student> getListOfStudent();



}
