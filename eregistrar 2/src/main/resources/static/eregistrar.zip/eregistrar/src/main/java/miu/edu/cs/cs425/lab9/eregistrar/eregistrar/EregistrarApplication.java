package miu.edu.cs.cs425.lab9.eregistrar.eregistrar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EregistrarApplication {

    public static void main(String[] args) {
        SpringApplication.run(EregistrarApplication.class, args);
    }

}
