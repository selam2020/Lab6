package miu.edu.cs.cs425.lab9.eregistrar.eregistrar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EregistrarApplicationTests {

    @Test
    void contextLoads() {
    }

}
