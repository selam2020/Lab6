package miu.edu.cs.cs425.lab9.eregistrar.eregistrar.service;

import miu.edu.cs.cs425.lab9.eregistrar.eregistrar.model.Student;
import miu.edu.cs.cs425.lab9.eregistrar.eregistrar.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpt  implements StudentService{
    @Autowired
    StudentRepository studentRepository;
@Override
    public  Iterable<Student> getListOfStudent(){
        return studentRepository.findAll();


    }
}
